-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 18, 2022 at 04:38 PM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cms`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `cat_id` int(3) NOT NULL AUTO_INCREMENT,
  `cat_title` varchar(255) NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(1, 'Bootstrap'),
(2, 'Javascript'),
(3, 'PHP'),
(21, 'HTML5'),
(5, 'Python'),
(6, 'React');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `comment_id` int(3) NOT NULL AUTO_INCREMENT,
  `comment_post_id` int(3) NOT NULL,
  `comment_author` varchar(255) NOT NULL,
  `comment_email` varchar(255) NOT NULL,
  `comment_content` text NOT NULL,
  `comment_status` varchar(255) NOT NULL,
  `comment_date` date NOT NULL,
  PRIMARY KEY (`comment_id`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`comment_id`, `comment_post_id`, `comment_author`, `comment_email`, `comment_content`, `comment_status`, `comment_date`) VALUES
(38, 73, '12', 'example@gmail.com', '12', 'unapproved', '2022-03-09');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE IF NOT EXISTS `posts` (
  `post_id` int(3) NOT NULL AUTO_INCREMENT,
  `post_category_id` int(3) NOT NULL,
  `post_title` varchar(255) NOT NULL,
  `post_author` varchar(255) DEFAULT NULL,
  `post_user` varchar(255) DEFAULT NULL,
  `post_date` date NOT NULL,
  `post_image` text NOT NULL,
  `post_content` text NOT NULL,
  `post_tags` varchar(255) NOT NULL,
  `post_status` varchar(255) NOT NULL DEFAULT 'draft',
  `post_views_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`post_id`)
) ENGINE=MyISAM AUTO_INCREMENT=75 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`post_id`, `post_category_id`, `post_title`, `post_author`, `post_user`, `post_date`, `post_image`, `post_content`, `post_tags`, `post_status`, `post_views_count`) VALUES
(73, 2, 'Javascript', NULL, '2', '2022-03-10', '2016-01-08.png', '121', 'javascript, course, class, great', 'published', 12),
(71, 21, 'Javascript', NULL, '2', '2022-03-10', '2016-01-08.png', '121', 'javascript, course, class, great', 'draft', 0),
(72, 21, 'Javascript', NULL, '2', '2022-03-10', '2016-01-08.png', '121', 'javascript, course, class, great', 'published', 0),
(68, 21, 'Javascript', NULL, '2', '2022-03-10', '2016-01-08.png', '121', 'javascript, course, class, great', 'draft', 0),
(69, 2, 'Javascript', NULL, '2', '2022-03-10', '2016-01-08.png', '121', 'javascript, course, class, great', 'draft', 0),
(70, 2, 'Javascript', NULL, '2', '2022-03-10', '2016-01-08.png', '121', 'javascript, course, class, great', 'draft', 0),
(65, 2, 'Javascript', NULL, '2', '2022-03-10', '2016-01-08.png', '121', 'javascript, course, class, great', 'published', 0),
(74, 1, 'Bootstrap', NULL, '5', '2022-03-17', '2015-11-17.png', 'Ut sed ante rhoncus, aliquam urna non, facilisis tellus. Quisque cursus, mi ac lacinia hendrerit, enim enim hendrerit magna, ac tempor mauris lorem nec augue. Nulla facilisi. Nulla mattis bibendum magna, ac tincidunt sapien lobortis rutrum. Nam ullamcorper dapibus sem et ornare. Proin luctus.', 'bootstrap, mile', 'published', 24),
(67, 21, 'Javascript', NULL, '2', '2022-03-10', '2016-01-08.png', '121', 'javascript, course, class, great', 'published', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(3) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_firstname` varchar(255) NOT NULL,
  `user_lastname` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_image` text,
  `user_role` varchar(255) NOT NULL,
  `randSalt` varchar(255) DEFAULT '$2y$10$iusesomecrazystrings22',
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `user_password`, `user_firstname`, `user_lastname`, `user_email`, `user_image`, `user_role`, `randSalt`) VALUES
(2, 'Janko', '$2y$10$824DtcM3.OF4d.BmvsDEPe73UgsAhhb5WDtkvHKyLRbSyHpLtIew.', 'Janko', 'Lukic', 'example@gmail.com12', 'user1.png', 'admin', NULL),
(4, 'Pera', '$1$48mCPFJb$ycbVHSCo8dJrr/.cQgGtD/', 'Pera', 'Peric', 'example@gmail.com', 'user1.png', 'admin', NULL),
(5, 'Mile', '$1$2hO6fhIo$4XNhuhmGjiR8PVaIGGZTc1', 'Milenko', 'Mitic', 'mile@gmail.com', 'user1.png', 'subscriber', NULL),
(9, 'Milka', '$2y$10$v7/9gN81jRnpc4f2lguWEOnYNHde6/1LNXTASkxUxHioAR8NlYFUS', 'Miladinka', 'MiladinoviÄ‡', 'm@gmail.com', '', 'subscriber', '$2y$10$iusesomecrazystrings22'),
(18, 'sima', '$2y$12$QW.GMmDl71zjnDwWwV118OPOa1Fc081PPAzExxkB5CGtxblbpZUHW', 'sima', 'simic', 'sima@gmail.com', NULL, 'subscriber', '$2y$10$iusesomecrazystrings22'),
(15, 'Paja', '$2y$10$zBlp89oJ2NEWvPEyXlquluuYb10Q3OrEhdFdOnhnzqhsC1NXtRJBe', 'Pavle123', 'Pajic', 'paja@paja.com', '', 'subscriber', '$2y$10$iusesomecrazystrings22'),
(12, 'Canic', '$2y$12$z2IBkku94.ZuhFdmXw5j/uPvnB6qT7WJNTjLaX7/rVA5FBYVQAsQC', 'Milka', 'Canic', 'dobro@jutro.com', NULL, 'subscriber', '$2y$10$iusesomecrazystrings22');

-- --------------------------------------------------------

--
-- Table structure for table `users_online`
--

DROP TABLE IF EXISTS `users_online`;
CREATE TABLE IF NOT EXISTS `users_online` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `session` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_online`
--

INSERT INTO `users_online` (`id`, `session`, `time`) VALUES
(1, 'vaqt3986da30mj7u2fbvm5m5hn', 1647265455),
(2, 'ojtbbedu48npdbk61i8redl8hj', 1646143416),
(3, 'tiqbag2g60e4m51rj8b55qkq90', 1646143494),
(4, 'faadln0qas9hpse0n3m5euol30', 1646146685),
(5, 'crgcajd98fbdb44c31ndkh0v31', 1646145298),
(6, '4o13qe9uj49qqe3nf5emdvlooj', 1646146691);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
