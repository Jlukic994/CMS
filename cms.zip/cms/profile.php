<?php include_once('includes/header.php');?>
<?php users_online(); ?>
<?php
    if(isset($_SESSION['username'])){
        $username=escape($_SESSION['username']);

        $query="SELECT * FROM users WHERE username='{$username}'";
        $select_user_profile_query=mysqli_query($conn,$query);

        while($row=mysqli_fetch_array($select_user_profile_query)){
            $user_id=$row['user_id'];
            $username=$row['username'];
            $user_password=$row['user_password'];
            $user_firstname=$row['user_firstname'];
            $user_lastname=$row['user_lastname'];
            $user_email=$row['user_email'];
            $user_image=$row['user_image'];
            $user_role=$row['user_role'];
        }

    }

    if(isset($_POST['update_profile'])){
        $user_firstname=escape($_POST['user_firstname']) ;
        $user_lastname=escape($_POST['user_lastname']) ;
        // $user_role=$_POST['user_role'] ;

        $user_image=$_FILES['user_image']['name'] ;
        $user_image_temp=$_FILES['user_image']['tmp_name'] ;

        $username=escape($_POST['username'] );
        $user_email=escape($_POST['user_email']) ;
        $user_password=escape($_POST['user_password'] );
        
         move_uploaded_file($user_image_temp, "images/$user_image");

         if(empty($user_image)){
            $query="SELECT * FROM users WHERE user_id=$user_id";
            $select_image=mysqli_query($conn,$query);

            while($row = mysqli_fetch_array($select_image)){
                $user_image=$row['user_image'];
            }
        }

        if(!empty($user_password)){
            $query_password="SELECT user_password FROM users WHERE user_id='$user_id'";
            $get_user_query=mysqli_query($conn,$query_password);
            confirmQuery($get_user_query);

            $row=mysqli_fetch_array($get_user_query);
            
            $db_user_password=$row['user_password'];


            if($db_user_password != $user_password){
                $hashed_password= password_hash($user_password, PASSWORD_BCRYPT, array('cost' => 10)); 
            }

        $query="UPDATE users SET
                user_firstname='$user_firstname',
                user_lastname='$user_lastname',
                user_image='$user_image',
                username='$username',
                user_email='$user_email',
                user_password='$hashed_password'
                WHERE user_id=$user_id
                ";

        $edit_user_query=mysqli_query($conn, $query);

        confirmQuery($edit_user_query);
    }

        $message="<div class='text-success'><h2>Profile Updated</h2></div>";

    }



?>

<!-- Navigation -->

<?php include_once('includes/navigation.php');?>

<!-- Page Content -->
<div class="container">

    <div class="row">

        <!-- Blog Entries Column -->
        <div class="col-md-12">
        <h1 class="page-header">
                            Welcome to Your Profile
                            <small><?php echo $_SESSION['username'];?></small>
                        </h1>
                        <?php if(isset($message)){
                            echo $message;
                            unset ($message);
                        } ?>
                       
                        <form action="" method="post" enctype="multipart/form-data">

                            <div class="form-group">
                                <label for="user_firstname">Firstname</label>
                                <input type="text" class="form-control" name="user_firstname" value="<?php echo $user_firstname?>">
                            </div>
                            <div class="form-group">
                                <label for="user_lastname">Lastname</label>
                                <input type="text" class="form-control"  name="user_lastname" value="<?php echo $user_lastname?>">
                            </div>
                            <div class="form-group">
                                <label for="username">Username</label>
                                <input type="text" class="form-control" name="username" value="<?php echo $username?>">
                            </div>
                            <div class="form-group">
                                <label for="user_email">Email</label>
                                <input type="email" class="form-control" name="user_email"  value="<?php echo $user_email?>">
                            </div>
                            <div class="form-group">
                                <label for="user_password">Password</label>
                                <input autocomplete="off" type="password" class="form-control" name="user_password" >
                            </div>
                            <div class="form-group">
                                <img width='100' src="../images/<?php echo $user_image?>" alt=""><br><br>
                                <input type="file" class="form-control" name="user_image">
                            </div>
                            <div class="form-group">
                                <input type="submit" class="btn btn-primary" name="update_profile" value="Update Profile">
                            </div>
                        </form>
    
    </div>
    <!-- /.row -->

    

    <?php include_once('includes/footer.php');?>