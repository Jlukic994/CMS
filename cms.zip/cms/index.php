<?php include_once('includes/header.php');?>
<?php users_online(); ?>

<!-- Navigation -->

<?php include_once('includes/navigation.php');?>

<!-- Page Content -->
<div class="container">

    <div class="row">

        <!-- Blog Entries Column -->
        <div class="col-md-8">

        <?php

            if(isset($_GET['page'])){
                $page=escape($_GET['page']);
            }else{
                $page="";
            }

            if($page=="" || $page==1){
                
                $page_1=0;
            }else{
                $page_1=($page * 5) - 5;
            }



            // QUERY FOR PAGGINATION
            $post_query_count="SELECT * FROM posts";
            $find_count=mysqli_query($conn,$post_query_count);
            $pagination_count=mysqli_num_rows($find_count);

            $pagination_count= ceil($pagination_count / 5);//CEIL FUNCTION GET YOU ROUND NUMBERS (CONVERT FROM FOLAT TO INTEGER)!!!!




        
            $query="SELECT * FROM posts WHERE post_status='published' ORDER BY post_id DESC LIMIT $page_1,5";
            if(isset($_POST['search'])){
                $search=escape($_POST['search']);
                $query="SELECT * FROM posts WHERE post_tags LIKE ('%$search%') AND post_status='published'";
            }

            $res=mysqli_query($conn,$query);
            $count=mysqli_num_rows($res);
            if($count==0) echo"<h1 class='text-center text-danger'>No Posts Right Now</h1>";
               
            while($row=mysqli_fetch_assoc($res)){
                $post_id=$row['post_id'];    
                $post_title=$row['post_title'];    
                $post_user=$row['post_user'];    
                $post_date=$row['post_date'];    
                $post_image=$row['post_image'];    
                $post_content=substr($row['post_content'], 0, 100);     
                
                if(isset($post_user) && !empty($post_user)){
                    $query="SELECT * FROM users WHERE user_id={$post_user}";
                    $select_user_query=mysqli_query($conn,$query);
                    confirmQuery($select_user_query);

                    while($row=mysqli_fetch_array($select_user_query)){
                        $user=$row['username'];
                    }
                }

        ?>

            
            <!-- First Blog Post -->
            <h2>
                <a href="post.php?p_id=<?php echo $post_id; ?>"><?php echo $post_title ?></a>
            </h2>
            <p class="lead">
                by <a href="author_post.php?user=<?php echo $post_user ?>&p_id=<?php echo $post_id ?>"><?php echo $user ?></a>
            </p>
            <p><span class="glyphicon glyphicon-time"></span> <?php echo $post_date ?></p>
            <hr>
            <a href="post.php?p_id=<?php echo $post_id; ?>"><img class="img-responsive" src="images/<?php echo $post_image;?>" alt=""></a>
            <hr>
            <p><?php echo $post_content ?>...</p>
            <a class="btn btn-primary" href="post.php?p_id=<?php echo $post_id; ?>">Read More <span class="glyphicon glyphicon-chevron-right"></span></a>

            <hr>

        <?php }  ?>

        </div>

        <!-- Blog Sidebar Widgets Column -->

        <?php include_once('includes/sidebar.php');?>
        
    </div>
    <!-- /.row -->

    <hr>

   <ul class="pager">
      <?php
      
      for($i=1; $i<=$pagination_count; $i++){
         if($i == $page){
            echo "<li><a class='active_link' href='index.php?page={$i}'>{$i}</a></li>";

            
         } else{
             echo "<li><a href='index.php?page={$i}'>{$i}</a></li>";
         }
            
      }
      
      
      ?>
   </ul> 

    <?php include_once('includes/footer.php');?>