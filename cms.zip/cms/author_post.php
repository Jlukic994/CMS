<?php include_once('includes/db.php');?>
<?php include_once('includes/header.php');?>


<!-- Navigation -->

<?php include_once('includes/navigation.php');?>

<!-- Page Content -->
<div class="container">

    <div class="row">

        <!-- Blog Entries Column -->
        <div class="col-md-8">

        <?php

            if(isset($_GET['p_id'])){
                $p_id=escape($_GET['p_id']);
                $post_user=escape($_GET['user']);
            }
        
            $query="SELECT * FROM posts WHERE post_user='{$post_user}'";
            if(isset($_POST['search'])){
                $search=escape($_POST['search']);
                $query="SELECT * FROM posts WHERE post_tags LIKE ('%$search%')";
            }

            $res=mysqli_query($conn,$query);
            $count=mysqli_num_rows($res);
            if($count==0) echo"<h1>NO RESULT</h1>";
               
            while($row=mysqli_fetch_assoc($res)){
                $post_title=$row['post_title'];    
                $post_user=$row['post_user'];    
                $post_date=$row['post_date'];    
                $post_image=$row['post_image'];    
                $post_content=$row['post_content'];    

                if(isset($post_user) && !empty($post_user)){
                    $query="SELECT * FROM users WHERE user_id={$post_user}";
                    $select_user_query=mysqli_query($conn,$query);
                    confirmQuery($select_user_query);

                    while($row=mysqli_fetch_array($select_user_query)){
                        $user=$row['username'];
                    }
                }
        ?>

            <h1 class="page-header">
                Page Heading
                <small>Secondary Text</small>
            </h1>

            <!-- First Blog Post -->
            <h2>
                <a href="post.php?p_id=<?php echo $post_id; ?>"><?php echo $post_title ?></a>
            </h2>
            <p class="lead">
                All post by <?php echo $user ?>
            </p>
            <p><span class="glyphicon glyphicon-time"></span> <?php echo $post_date ?></p>
            <hr>
            <img class="img-responsive" src="images/<?php echo $post_image;?>" alt="">
            <hr>
            <p><?php echo $post_content ?></p>

            <hr>

        <?php } ?>

                <!-- Blog Comments -->

                <?php
                
                    if(isset($_POST['create_comment'])){
                        $p_id=escape($_GET['p_id']);

                        $comment_author=escape($_POST['comment_author']);
                        $comment_email=escape($_POST['comment_email']);
                        $comment_content=escape($_POST['comment_content']);
                        $comment_date=date('Y-m-d');

                         if(!empty($comment_author) && !empty($comment_email) && !empty($comment_content)){
                            $query="INSERT INTO comments SET
                            comment_post_id=$p_id,
                            comment_author='{$comment_author}',
                            comment_email='{$comment_email}',
                            comment_content='{$comment_content}',
                            comment_status='unapproved',
                            comment_date='{$comment_date}'
                            ";

                            $create_comment_query=mysqli_query($conn,$query);

                            if(!$create_comment_query){
                                die("Query failed !!!  " . mysqli_error($conn));
                            }

                            $query="UPDATE posts SET post_comment_count=post_comment_count + 1 WHERE post_id=$p_id";
                            $update_comment_count_query=mysqli_query($conn, $query);

                        }else{
                            
                            echo "<script>alert('Fields cannot be empty ')</script>";

                        }  
                    }
                ?>

        </div>

        <!-- Blog Sidebar Widgets Column -->

        <?php include_once('includes/sidebar.php');?>
        
    </div>
    <!-- /.row -->

    <hr>

    <?php include_once('includes/footer.php');?>