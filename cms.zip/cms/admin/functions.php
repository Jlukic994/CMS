<?php

    //Function for cleaning data before it gets to database 
    function escape($string){
        global $conn;
        return mysqli_real_escape_string($conn, trim(strip_tags($string)));
    }

    // Check how much users are online 
    function users_online(){

        if(isset($_GET['onlineusers'])){

            global $conn;
            if(!$conn){
                session_start();
                include("../includes/db.php");

                  // QUERY FOR CHECKING USERS ONLINE 
                $session= session_id();
                $time=time();
                $time_out_in_seconds=30;
                $time_out=$time - $time_out_in_seconds;
                $query = "SELECT * FROM users_online WHERE session='$session'";
                $send_query=mysqli_query($conn, $query);
                $count=mysqli_num_rows($send_query);

                    if($count==NULL){
                        mysqli_query($conn,"INSERT INTO users_online(session,time) VALUES('$session','$time')");
                    }else{
                        mysqli_query($conn,"UPDATE users_online SET time='{$time}' WHERE session='$session'");
                    }

                $online_query="SELECT * FROM users_online WHERE time > '$time_out'";
                $users_online_query=mysqli_query($conn, $online_query);
                echo $count_user=mysqli_num_rows($users_online_query);
            }
        }//Get request isset()
    }
    users_online();

    // Check if our quey work.. if not we display mesage
    function confirmQuery($result){
        global $conn;
        if(!$result){
            die("query faild ." . mysqli_error($conn) );
        }
    }

    // Insert new categories in database
    function insert_categories(){
        global $conn;
        if(isset($_POST['submit'])){
            $cat_title=$_POST['cat_title'];

            if($cat_title=="" || empty($cat_title)){
            echo "This field should not be empty!!";
            }else{
                $query="INSERT into categories SET
                cat_title='$cat_title'"; 
                $create_category_query=mysqli_query($conn,$query);
                confirmQuery($create_category_query);
            }
        }
        
    }

    // reading all data from categories table and actions to update and delete them(with JS confirmation for delete)
    function findAllCategories(){
        global $conn;

        $query="SELECT * FROM categories";
        $select_categories=mysqli_query($conn, $query);
        
        while($row= mysqli_fetch_assoc($select_categories)){
            $cat_id=$row['cat_id'];  
            $cat_title=$row['cat_title']; 
            
            echo "<tr>";
            echo "<td>{$cat_id}.</td>";
            echo "<td>{$cat_title}</td>";
            // echo "<td><a onClick=\"javascript: return confirm('Are you sure you want to delete'); \" class='btn btn-danger' href='categories.php?delete={$cat_id}'>Delete</a></td>";
            echo "<td><a rel='$cat_id' class='btn btn-danger delete_link'  href='javascript:void(0)'>Delete</a></td>";
            echo "<td><a class='btn btn-info' href='categories.php?update={$cat_id}'>Update</a></td>";
            echo "</tr>";
        } 
    }

    //deleting categories with id that we get from GET method and redirecting to same page with header function (so we dont need to refresh page)
    function deleteCategories(){
        global $conn;

        if(isset($_GET['delete'])){
            $the_cat_id=$_GET['delete'];

            $query="DELETE FROM categories WHERE cat_id={$the_cat_id}";
            $delete_query=mysqli_query($conn, $query);
            header("location:categories.php");
        }
    }

    // SELECT * FROM CATEGORIES FOR NEW POST
    function selectCategories(){
            global $conn;
            $query="SELECT * FROM categories";
            $select_categories=mysqli_query($conn, $query);

            confirmQuery($select_categories);

            while($row= mysqli_fetch_assoc($select_categories)){
                $cat_id=$row['cat_id'];  
                $cat_title=$row['cat_title'];   
                 
                echo "<option value='$cat_id'>{$cat_title}</option>";
            }
    }

    // SELECT * FROM USERS FOR NEW POST
    function selectUsers(){
            global $conn;

            $query="SELECT * FROM users";
                $select_users=mysqli_query($conn, $query);

                confirmQuery($select_users);

                while($row= mysqli_fetch_assoc($select_users)){
                    $user_id=$row['user_id'];  
                    $username=$row['username'];   
                     
                    echo "<option value='$user_id'>{$username}</option>";
                }
    }

    // CREATE POST
    function createPost(){
        global $conn;
        if(isset($_POST['create_post'])){

            $post_title=escape($_POST['post_title']) ;
            $post_user=escape($_POST['post_user']) ;
            $post_category_id=escape($_POST['post_category']) ;
            $post_status=escape($_POST['post_status']) ;
    
            $post_image=$_FILES['post_image']['name'] ;
            $post_image_temp=$_FILES['post_image']['tmp_name'] ;
    
            $post_tags=escape($_POST['post_tags']) ;
            $post_content=escape($_POST['post_content']) ;
            $post_date=escape($_POST['post_date']) ;
            
            move_uploaded_file($post_image_temp, "../images/$post_image");
    
            $query="INSERT INTO posts SET
                    post_title='$post_title',
                    post_user='$post_user',
                    post_category_id=$post_category_id,
                    post_status='$post_status',
                    post_image='$post_image',
                    post_tags='$post_tags',
                    post_content='$post_content',
                    post_date='$post_date'
                    ";


            $query='INSERT INTO posts SET';
            $query.="post_title='$post_title'";
            $query.=
    
            $create_post_query=mysqli_query($conn, $query);
    
            confirmQuery($create_post_query);
    
            $post_id=mysqli_insert_id($conn);
    
            echo "<p class='bg-success'>Post Created. <a href='../post.php?p_id=$post_id'>View Post</a> or <a href='posts.php'>Edit Other Posts</a></p>";
        }
    }

    // for counting rows in tables
    function recordCount($table){

        global $conn;
        $query="SELECT * FROM " . $table;
        $select_all_post=mysqli_query($conn,$query);

        $result=mysqli_num_rows($select_all_post);

        if($result<1)return 0;
        else{
            confirmQuery($result);
            return $result;
        }
    }

    // checking status for post/comment/user (for diagram)
    function checkStatus($table, $column, $status){
        
        global $conn;
        

        $query="SELECT * FROM $table WHERE $column='{$status}'";
        $result=mysqli_query($conn,$query);
        if(!$result)return 0;
        else{
            confirmQuery($result);
            return mysqli_num_rows($result);
        }
        
    }
     
    // Checkbox function for view all posts
    function checkBox(){
        global $conn;

        if(isset($_POST['checkBoxArray'])){
        

            foreach($_POST['checkBoxArray'] as  $post_id){
    
                $bulk_options=escape($_POST['bulk_options']);
    
                switch($bulk_options){
                    case 'published':
                        $query="UPDATE posts SET post_status='{$bulk_options}' WHERE post_id=$post_id";
                        $update_publish_query=mysqli_query($conn, $query);
                        confirmQuery($update_publish_query);
                    break;
                    case 'draft':
                        $query="UPDATE posts SET post_status='{$bulk_options}' WHERE post_id=$post_id";
                        $update_draft_query=mysqli_query($conn, $query);
                        confirmQuery($update_draft_query);
                    break;
                    case 'clone':
                        $query="SELECT * FROM posts WHERE post_id=$post_id";
                        $select_post_query=mysqli_query($conn,$query);
    
                        while($row=mysqli_fetch_array($select_post_query)){
                            $post_title=$row['post_title'];
                            $post_category_id=$row['post_category_id'];
                            $post_date=$row['post_date'];
                            $post_user=$row['post_user'];
                            $post_status=$row['post_status'];
                            $post_image=$row['post_image'];
                            $post_tags=$row['post_tags'];
                            $post_content=$row['post_content'];
                            
                        }
                        $query="INSERT INTO posts SET
                        post_title='{$post_title}',
                        post_category_id='{$post_category_id}',
                        post_date='{$post_date}',
                        post_user='{$post_user}',
                        post_status='{$post_status}',
                        post_image='{$post_image}',
                        post_tags='{$post_tags}',
                        post_content='{$post_content}'
                        ";
                        $copy_query= mysqli_query($conn,$query);
                        confirmQuery($copy_query);
                    break;
                    case 'delete':
                        $query="DELETE FROM posts WHERE post_id=$post_id";
                        $delete_query=mysqli_query($conn, $query);
                        confirmQuery($delete_query);
                        $query="DELETE FROM comments WHERE comment_post_id={$post_id}";
                        $delete_comment_query=mysqli_query($conn, $query);
                        confirmQuery($delete_comment_query);
                    break;
                }
            }
        }
    

        
    }

    // for sessions that are redirected with massage from other page
    function sessionSet($value){

        if(isset($_SESSION[$value])){
            echo $_SESSION[$value];
            unset ($_SESSION[$value]);
        }
    }

    // view all posts function
    function viewAllPosts(){
        global $conn;

        // $query="SELECT * FROM posts and categories  ORDER BY post_id DESC";
        $query="SELECT posts.post_id, posts.post_user, posts.post_title, posts.post_category_id, posts.post_status, posts.post_image, posts.post_tags, posts.post_date, posts.post_views_count, ";
        $query .="categories.cat_id, categories.cat_title ";
        $query .="FROM posts LEFT JOIN categories ON posts.post_category_id=categories.cat_id  ORDER BY posts.post_id DESC";
        $select_posts=mysqli_query($conn,$query);
        
        while($row=mysqli_fetch_assoc($select_posts)){
            $post_id=$row['post_id'];
            $post_user=$row['post_user'];
            $post_user=$row['post_user'];
            $post_title=$row['post_title'];
            $post_category_id=$row['post_category_id'];
            $post_status=$row['post_status'];
            $post_image=$row['post_image'];
            $post_tags=$row['post_tags'];
            $post_date=$row['post_date'];
            $post_views_count=$row['post_views_count'];

            $cat_id=$row['cat_id'];
            $cat_title=$row['cat_title'];

            echo "<tr>"; ?>

<td><input type='checkbox' class='checkBoxes' name='checkBoxArray[]' value='<?php echo $post_id; ?>'></td>


<?php

            echo "<td>{$post_id}</td>";

            $query="SELECT * FROM users WHERE user_id={$post_user}";
            $select_user_query=mysqli_query($conn,$query);
            confirmQuery($select_user_query);
            while($row=mysqli_fetch_array($select_user_query)){
                $post_user=$row['username'];
            }

            echo "<td>{$post_user}</td>";

            echo "<td>{$post_title}</td>";

            // $query="SELECT * FROM categories WHERE cat_id=$post_category_id";
            //     $select_categories_id=mysqli_query($conn, $query);

            // while($row= mysqli_fetch_assoc($select_categories_id)){
            //     $cat_id=$row['cat_id'];  
            //     $cat_title=$row['cat_title'];

            echo "<td>{$cat_title}</td>";    
            echo "<td>{$post_status}</td>";
            echo "<td><img  width='60px' src='../images/{$post_image}' alt='{$post_image}'></td>";
            echo "<td>{$post_tags}</td>";



        /////////COMENT COUNT FOR DISPLAYING IN ALL POSTS //////////////////////////////
            $query="SELECT * FROM comments WHERE comment_post_id=$post_id";
            $send_comment_query=mysqli_query($conn,$query);

            $row=mysqli_fetch_array($send_comment_query);
            $count_comment=mysqli_num_rows($send_comment_query);

            echo "<td><a href='comments.php?id={$post_id}&source=post_comment'>{$count_comment}</a></td>";
        ////////////////////////////////////////////////////////////////////
            echo "<td>{$post_date}</td>";
            echo "<td><a class='text-info' href='posts.php?source=edit_post&p_id={$post_id}'>Edit</a></td>";

            echo "<td><a class='text-info' href='../post.php?p_id={$post_id}'>View Post</a></td>";

            echo "<td><a class='text-info' href='posts.php?publish_post_id={$post_id}'>Publish</a></td>";
            // echo "<td><a onClick=\"javascript: return confirm('Are you sure you want to delete'); \" class='text-danger' href='posts.php?delete={$post_id}'>Delete</a></td>";
            echo "<td><a rel='$post_id' class='text-danger delete_link'  href='javascript:void(0)'>Delete</a></td>";
            echo "<td><a  href='posts.php?reset={$post_id}'>$post_views_count</a></td>";
            echo "</tr>";

        }
    }
    
    // View all comments function
    function viewAllComments(){
        global $conn;

        $query="SELECT * FROM comments";
        $select_comments=mysqli_query($conn,$query);
        
        while($row=mysqli_fetch_assoc($select_comments)){
            $comment_id=$row['comment_id'];
            $comment_post_id=$row['comment_post_id'];
            $comment_author=$row['comment_author'];
            $comment_content=$row['comment_content'];
            $comment_email=$row['comment_email'];
            $comment_status=$row['comment_status'];
            $comment_date=$row['comment_date'];

            echo "<tr>";
            echo "<td>{$comment_id}</td>";
            echo "<td>{$comment_author}</td>";
            echo "<td>{$comment_content}</td>";
            echo "<td>{$comment_email}</td>";
            echo "<td>{$comment_status}</td>";

            $query="SELECT * FROM posts WHERE post_id=$comment_post_id ";
            $select_post_id_query=mysqli_query($conn,$query);

            while($row=mysqli_fetch_assoc($select_post_id_query)){
                    $post_id=$row['post_id'];
                    $post_title=$row['post_title'];

                    echo "<td><a href='../post.php?p_id=$post_id'>$post_title</a></td>";
            }

            echo "<td>{$comment_date}</td>";
            echo "<td><a class='text-info' href='comments.php?approve={$comment_id}'>Approve</a></td>";
            echo "<td><a class='text-danger' href='comments.php?unapprove={$comment_id}'>Unapprove</a></td>";
            echo "<td><a rel='$comment_id' class='text-danger delete_link'  href='javascript:void(0)'>Delete</a></td>";
            echo "</tr>";

        }
    }


    //  update on button function....
    function updateFunction($session, $table, $cell, $value, $tableId, $valueId, $link ){
        global $conn;

        if(isset($_GET[$session])){
            $valueId=escape($_GET[$session]);

            $query="UPDATE $table SET $cell='{$value}' WHERE $tableId={$valueId}";
            $result=mysqli_query($conn, $query);
            confirmQuery($result);
            header("location:" .$link ."");
            return $result;
        }
    }

    //  delete function....
    function deleteFunction($session, $table, $tableId, $valueId, $link ){
        global $conn;

        if(isset($_GET[$session])){
            if(isset($_SESSION['user_role'])){

                if($_SESSION['user_role']=='admin'){
                    $valueId=escape($_GET[$session]);

                    $query="DELETE FROM $table WHERE $tableId={$valueId}";
                    $result=mysqli_query($conn, $query);
                    confirmQuery($result);
                    header("location:" .$link ."");
                    return $result;
                }
            }
        }
    }

    // VIEW ALL USERS
    function viewAllUsers(){
        global $conn;

        $query="SELECT * FROM users ORDER BY user_id ASC";
        $select_users=mysqli_query($conn,$query);
        
        while($row=mysqli_fetch_assoc($select_users)){
            $user_id=$row['user_id'];
            $username=$row['username'];
            $user_password=$row['user_password'];
            $user_firstname=$row['user_firstname'];
            $user_lastname=$row['user_lastname'];
            $user_email=$row['user_email'];
            $user_image=$row['user_image'];
            $user_role=$row['user_role'];

            echo "<tr>";
            echo "<td>{$user_id}</td>";
            echo "<td>{$username}  </td>";
            echo "<td><img class='ml-10 img-circle'  width='40px' src='../images/{$user_image}' alt='{$user_image}'></td>";
            echo "<td>{$user_firstname}</td>";
            echo "<td>{$user_lastname}</td>";
            echo "<td>{$user_email}</td>";

            echo "<td>{$user_role}</td>";
            echo "<td><a class='text-info' href='users.php?change_to_admin={$user_id}'>Admin</a></td>";
            echo "<td><a class='text-success' href='users.php?change_to_sub={$user_id}'>Subscriber</a></td>";
            echo "<td><a class='text-success' href='users.php?source=edit_user&edit_user={$user_id}'>Edit</a></td>";
            


            echo "<td><a rel='$user_id' class='text-danger delete_link'  href='javascript:void(0)'>Delete</a></td>";




            echo "</tr>";
        }

    }

    // VIEW ALL COMMENTS FOR SPECIFIC POST
    function postComments(){
        global $conn;

        if(isset($_GET['id'])){
            $post_id=escape($_GET['id']);
        }
        
        $query="SELECT * FROM comments WHERE comment_post_id={$post_id}";
        $select_comments=mysqli_query($conn,$query);

        $count_comments=mysqli_num_rows($select_comments);

        if($count_comments==0){
            $_SESSION['comm']="<div class='text-center text-danger'><h3>No comments for that post right now!</h3></div>";
            header("Location:posts.php");
        }
        
        while($row=mysqli_fetch_assoc($select_comments)){
            $comment_id=$row['comment_id'];
            $comment_post_id=$row['comment_post_id'];
            $comment_author=$row['comment_author'];
            $comment_content=$row['comment_content'];
            $comment_email=$row['comment_email'];
            $comment_status=$row['comment_status'];
            $comment_date=$row['comment_date'];
           
            echo "<tr>";
            echo "<td>{$comment_id}</td>";
            echo "<td>{$comment_author}</td>";
            echo "<td>{$comment_content}</td>";
            echo "<td>{$comment_email}</td>";
            echo "<td>{$comment_status}</td>";

            $query="SELECT * FROM posts WHERE post_id=$comment_post_id ";
            $select_post_id_query=mysqli_query($conn,$query);

            while($row=mysqli_fetch_assoc($select_post_id_query)){
                    $post_id=$row['post_id'];
                    $post_title=$row['post_title'];

                    echo "<td><a href='../post.php?p_id=$post_id'>$post_title</a></td>";
            }
            echo "<td>{$comment_date}</td>";
            echo "<td><a class='text-info' href='comments.php?source=post_comment&approve={$comment_id}&id={$post_id}'>Approve</a></td>";
            echo "<td><a class='text-danger' href='comments.php?source=post_comment&unapprove={$comment_id}&id={$post_id}'>Unapprove</a></td>";
            echo "<td><a rel='$post_id' rel2='$comment_id' class='text-danger delete_link'  href='javascript:void(0)'>Delete</a></td>";
            echo "</tr>";

        }
    }

    // ADD USER
    function addUser(){
        global $conn;
        if(isset($_POST['create_user'])){
            $user_firstname=escape($_POST['user_firstname'] );
            $user_lastname=escape($_POST['user_lastname']) ;
            $user_role=escape($_POST['user_role']) ;
    
            $user_image=$_FILES['user_image']['name'] ;
            $user_image_temp=$_FILES['user_image']['tmp_name'] ;
    
            $username=escape($_POST['username']) ;
            $user_email=escape($_POST['user_email']) ;
            $user_password=escape($_POST['user_password']) ;
    
            $user_password= password_hash($user_password, PASSWORD_BCRYPT, array('cost' => 10)); 
            
             move_uploaded_file($user_image_temp, "../images/$user_image");
    
            $query="INSERT INTO users SET
                    user_firstname='$user_firstname',
                    user_lastname='$user_lastname',
                    user_role='$user_role',
                    user_image='$user_image',
                    username='$username',
                    user_email='$user_email',
                    user_password='$user_password'
                    ";
    
            $create_user_query=mysqli_query($conn, $query);
    
            confirmQuery($create_user_query);
    
            echo "User Created:" . " " . "<a class='text-primary' href='users.php'>View Users</a>";
        }
    }

    // SELECT * FROM CATEGORIES FOR EDIT POST
    function editCategories(){
        global $conn;
        global $post_category_id;

        $query= "SELECT * FROM categories";
        $select_categories=mysqli_query($conn, $query);

        confirmQuery($select_categories);

        while($row=mysqli_fetch_assoc($select_categories)){
            $cat_id=$row['cat_id'];
            $cat_title=$row['cat_title'];



            if($cat_id==$post_category_id){

                echo "<option selected value='{$cat_id}'>{$cat_title}</option>";

            }else{
                echo "<option value='{$cat_id}'>{$cat_title}</option>";

            }

        }
    }

    // SELECT * FROM USERS FOR EDIT POST
    function editUser(){
        global $conn;
        global $post_user;
        $query="SELECT * FROM users";
        $select_users=mysqli_query($conn, $query);

        confirmQuery($select_users);

        while($row= mysqli_fetch_assoc($select_users)){
            $user_id=$row['user_id'];  
            $username=$row['username'];   

            if($user_id==$post_user){

                echo "<option selected value='{$user_id}'>{$username}</option>";

            }else{
                echo "<option value='{$user_id}'>{$username}</option>";

            }
        }    
    }
   
    // CHECK IF USERNAME ALREADY EXISTS
    function usernameExists($username){

            global $conn;
            $query = "SELECT username FROM users WHERE username='{$username}'";
            $result=mysqli_query($conn, $query);
            confirmQuery($result);

            if(mysqli_num_rows($result) > 0){
                return true;
            }else{
                return false;
            }
    }

    function emailExists($email){

        global $conn;
        $query = "SELECT user_email FROM users WHERE user_email='{$email}'";
        $result=mysqli_query($conn, $query);
        confirmQuery($result);

        if(mysqli_num_rows($result) > 0){
            return true;
        }else{
            return false;
        }
    }
   
    // HEADER REDIRECTION FUNCTION
    function redirect($location){
        return header("Location:" . $location);
    }


?>