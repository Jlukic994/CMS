<?php include_once('delete_modal.php');?>
<table class="table table-bordered table-hover">
    <thead>
        <tr>
            <th>ID</th>
            <th>Author</th>
            <th>Comment</th>
            <th>Email</th>
            <th>Status</th>
            <th>In Response to</th>
            <th>Date</th>
            <th colspan='3'>Actions</th>
        </tr>
    </thead>
    <tbody>

        <?php postComments(); ?>

    </tbody>
</table>

<?php

    // UNAPPROVE COMMENT
    updateFunction('unapprove', 'comments', 'comment_status', 'unapproved', 'comment_id', '$comment_id', 'comments.php?source=post_comment&id=' . $_GET['id'] .'' );

    // APPROVE COMMENT
    updateFunction('approve', 'comments', 'comment_status', 'approve', 'comment_id', '$comment_id', 'comments.php?source=post_comment&id=' . $_GET['id'] .'' );

    // DELETE COMMENT
    // deleteFunction('delete', 'comments', 'comment_id', '$comment_id', '$comment_id', 'comments.php?source=post_comment&id='. $_GET['id'] .'' );
    /////////WONT REDIRECT WITH FUNCTION///////

    if(isset($_GET['delete'])){
        $comment_id=escape($_GET['delete']);

        $query="DELETE FROM comments WHERE comment_id={$comment_id}";
        $delete_query=mysqli_query($conn, $query);

        confirmQuery($delete_query);
        header("location:comments.php?source=post_comment&id=". $_GET['id'] ."");
    }


?>
<script>

$(document).ready(function(){

   $(".delete_link").on('click', function(){
       var post_id= $(this).attr("rel");
       var comment_id= $(this).attr("rel2");
       var delete_url="comments.php?source=post_comment&delete="+ comment_id +"&id=" +post_id +"";

       $(".modal_delete_link").attr("href", delete_url );

       $("#myModal").modal('show')

   });
}); 

</script>