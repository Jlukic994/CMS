<?php include_once('delete_modal.php');?>
<?php checkBox();?>
<form action="" method="post">
    <table class="table table-bordered table-hover">
        <div id="bulkOptionsContainer" class="col-xs-4 pl-0">
            <select class="form-control" name="bulk_options" id="">
                <option value="">Select Options</option>
                <option value="published">Publish</option>
                <option value="draft">Draft</option>
                <option value="clone">Clone</option>
                <option value="delete">Delete</option>
            </select>
        </div>
        <div class="col-xs-4">
            <input type="submit" name="submit" class="btn btn-success" value="Apply">
            <a href="posts.php?source=add_post" class="btn btn-primary">Add New</a>
        </div><br><br><br>

        <?php sessionSet('comm');?>

        <thead>
            <tr>
                <th><input type="checkbox" id="selectAllBoxes"></th>
                <th>ID</th>
                <th>User</th>
                <th>Titile</th>
                <th>Category</th>
                <th>Status</th>
                <th>Images</th>
                <th>Tags</th>
                <th>Comments</th>
                <th>Date</th>
                <th colspan='4'>Actions</th>
                <th>Views</th>
            </tr>
        </thead>
        <tbody>

            <?php viewAllPosts(); ?>  

        </tbody>
    </table>
</form>
<?php

    // DELETE POST FUNCTION
    deleteFunction('delete', 'posts', 'post_id', '$post_id', 'posts.php');

    // DELETE COMMENTS FOR THAT POST
    deleteFunction('delete', 'comments', 'comment_post_id', '$post_id', 'posts.php');
       
    // RESET POST VIEWS
    updateFunction('reset', 'posts','post_views_count', 0, 'post_id', '$post_id', 'posts.php' );

    //publish post
    updateFunction('publish_post_id', 'posts','post_status', 'published', 'post_id', '$post_id', 'posts.php' );
      
?>
<script>

    $(document).ready(function(){

       $(".delete_link").on('click', function(){
           var id= $(this).attr("rel");
           var delete_url="posts.php?delete="+ id +"";

           $(".modal_delete_link").attr("href", delete_url );

           $("#myModal").modal('show')

       });
    }); 

</script>