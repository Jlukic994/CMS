<?php include_once('delete_modal.php');?>
<table class="table table-bordered table-hover">
    <thead>
        <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Avatar</th>
            <th>Firstname</th>
            <th>Lastname</th>
            <th>Email</th>
            <th>Role</th>
            <!-- <th>Date</th> -->
            <th colspan='4'>Actions</th>
        </tr>
    </thead>
    <tbody>

        <?php viewAllUsers(); ?>

    </tbody>
</table>

<?php

    // CHANGE USER ROLE TO ADMIN
    updateFunction('change_to_admin', 'users', 'user_role', 'admin', 'user_id', '$user_id', 'users.php' );

    // CHANGE USER ROLE TO SUBSCRIBER
    updateFunction('change_to_sub', 'users', 'user_role', 'subscriber', 'user_id', '$user_id', 'users.php' );

    // DELETE USER
    deleteFunction('delete', 'users', 'user_id', '$user_id', 'users.php' );

?>

<script>

    $(document).ready(function(){

       $(".delete_link").on('click', function(){
           var id= $(this).attr("rel");
           var delete_url="users.php?delete="+ id +"";

           $(".modal_delete_link").attr("href", delete_url );

           $("#myModal").modal('show')

       });
    }); 

</script>