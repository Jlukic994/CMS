<?php include_once('delete_modal.php');?>
<table class="table table-bordered table-hover">
    <thead>
        <tr>
            <th>ID</th>
            <th>Author</th>
            <th>Comment</th>
            <th>Email</th>
            <th>Status</th>
            <th>In Response to</th>
            <th>Date</th>
            <th colspan='3'>Actions</th>
        </tr>
    </thead>
    <tbody>

        <?php viewAllComments() ?>

    </tbody>
</table>

<?php
    // Update comment_status to UNAPPROVE
    updateFunction('unapprove', 'comments', 'comment_status', 'unapproved', 'comment_id', '$comment_id', 'comments.php' );

    // Update comment_status to APPROVE
    updateFunction('approve', 'comments', 'comment_status', 'approved', 'comment_id', '$comment_id', 'comments.php' );

    // DELETE COMMENT
    deleteFunction('delete', 'comments', 'comment_id', '$comment_id', 'comments.php' )
?>


<script>
// SCRIPT FOR POPUP(TO CONFIRM DELETE)
$(document).ready(function(){

   $(".delete_link").on('click', function(){
       var id= $(this).attr("rel");
       var delete_url="comments.php?delete="+ id +"";

       $(".modal_delete_link").attr("href", delete_url );

       $("#myModal").modal('show')

   });
}); 

</script>