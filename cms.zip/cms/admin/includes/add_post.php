<?php createPost();?>

<form action="" method="post" enctype="multipart/form-data">

    <div class="form-group">
        <label for="post_title">Post Title</label>
        <input type="text" class="form-control" name="post_title">
    </div>
    <div class="form-group">
        <label for="post_category">Category</label>
        <select name="post_category" id="post_category">
            
            <?php selectCategories(); ?>
               
        </select>
    </div>
    <div class="form-group">
        <label for="post_user">Users</label>
        <select name="post_user" id="post_user">

            <?php selectUsers(); ?>
            
        </select>
    </div>
    <div class="form-group">
        <select name="post_status" id="">
            <option value="draft">Post Status</option>
            <option value="published">Publish</option>
            <option value="draft">Draft</option>
        </select>
    </div>
    <div class="form-group">
        <label for="post_image">Post Image</label>
        <input type="file"  name="post_image">
    </div>
    <div class="form-group">
        <label for="post_tags">Post Tags</label>
        <input type="text" class="form-control" name="post_tags">
    </div>
    <div class="form-group">
        <label for="post_date">Post Date</label>
        <input type="date" class="form-control" name="post_date">
    </div>
    <div class="form-group">
        <label for="post_content">Post content</label>
        <textarea  class="form-control" name="post_content" id="body" cols="30" rows="10"></textarea>
    </div>
    <div class="form-group">
        <input type="submit" class="btn btn-primary" name="create_post" value="Add Post">
    </div>
</form>