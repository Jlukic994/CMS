<?php
     
     if(isset($_GET['p_id'])){
        $post_id=escape($_GET['p_id']);

     }
     $query="SELECT * FROM posts WHERE post_id=$post_id";
     $select_posts_by_id=mysqli_query($conn,$query);
     
     while($row=mysqli_fetch_assoc($select_posts_by_id)){
         $post_id=$row['post_id'];
         $post_user=$row['post_user'];
         $post_title=$row['post_title'];
         $post_category_id=$row['post_category_id'];
         $post_status=$row['post_status'];
         $post_image=$row['post_image'];
         $post_tags=$row['post_tags'];
         $post_date=$row['post_date'];
         $post_content=$row['post_content'];
     }

     if(isset($_POST['update_post'])){
         $post_user=escape($_POST['post_user']);
         $post_title=escape($_POST['post_title']);
         $post_category_id=escape($_POST['post_category']);
         $post_status=escape($_POST['post_status']);
         $post_image=$_FILES['image']['name'];
         $post_image_temp=$_FILES['image']['tmp_name'];
         $post_content=escape($_POST['post_content']);
         $post_tags=escape($_POST['post_tags']);
         $post_date=escape($_POST['post_date']);

         move_uploaded_file($post_image_temp, "../images/$post_image");

         if(empty($post_image)){
             $query="SELECT * FROM posts WHERE post_id=$post_id";
             $select_image=mysqli_query($conn,$query);

             while($row = mysqli_fetch_array($select_image)){
                 $post_image=$row['post_image'];
             }
         }

         $query="UPDATE posts SET
                post_title='{$post_title}',
                post_user='{$post_user}',
                post_category_id='{$post_category_id}',
                post_status='{$post_status}',
                post_image='{$post_image}',
                post_content='{$post_content}',
                post_tags='{$post_tags}',
                post_date='{$post_date}'
                WHERE post_id=$post_id
         ";


        $update_post_query=mysqli_query($conn,$query);

        confirmQuery($update_post_query);

         echo "<p class='bg-success'>Post Updated. <a href='../post.php?p_id=$post_id'>View Post</a> or <a href='posts.php'>Edit Other Posts</a></p>";

     }
?>
<form action="" method="post" enctype="multipart/form-data">

    <div class="form-group">
        <label for="post_title">Post Title</label>
        <input value="<?php echo $post_title;?>" type="text" class="form-control" name="post_title">
    </div>
    <div class="form-group">
        <label for="post_category">Category</label>
        <select name="post_category" id="post_category">

            <?php  editCategories();  ?>

        </select>
    </div>
    <div class="form-group">
        <label for="post_user">Users</label>
        <select name="post_user" id="post_user">
            
            <?php editUser(); ?>

        </select>
    </div>
    <div class="form-group">
    <select name="post_status" id="">
        <option value="<?php echo $post_status;?>"><?php echo $post_status;?></option>
        <?php
            if($post_status=='published'){
                echo "<option value='draft'>draft</option>";
            }else{
                echo "<option value='published'>publish</option>";
            }
        ?>
    </select>
    </div> 


    <div class="form-group">
        <img width='100' src="../images/<?php echo $post_image?>" alt=""><br><br>
        <input  type="file" name="image">
    </div>
    <div class="form-group">
        <label for="post_tags">Post Tags</label>
        <input value="<?php echo $post_tags;?>" type="text" class="form-control" name="post_tags">
    </div>
    <div class="form-group">
        <label for="post_date">Post Date</label>
        <input value="<?php echo $post_date;?>" type="date" class="form-control" name="post_date">
    </div>
    <div class="form-group">
        <label for="post_content">Post content</label>
        <textarea   class="form-control" name="post_content" id="body" cols="30" rows="10"><?php echo str_replace('&nbsp', '<br>', $post_content ) ;?></textarea>
    </div>
    <div class="form-group">
        <input type="submit" class="btn btn-primary" name="update_post" value="Edit Post">
    </div>
</form>