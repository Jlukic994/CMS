<?php include_once("db.php"); ?>
<?php include_once('../admin/functions.php'); ?>
<?php  session_start(); ?>
<?php

    if(isset($_POST['login'])){

        $username=escape($_POST['username']);
        $password=escape($_POST['password']);

    //    $username=mysqli_real_escape_string($conn, $username);
    //    $password=mysqli_real_escape_string($conn, $password);

       $query="SELECT * FROM users WHERE username='{$username}' "; //AND user_password='{$passwrod}'
       $select_user_query=mysqli_query($conn,$query);

       if(!$select_user_query){
           die("Query failed" . mysqli_error($conn));
       }

       while($row=mysqli_fetch_array($select_user_query)){
            $db_user_id=$row['user_id'];
            $db_username=$row['username'];
            $db_user_password=$row['user_password'];
            $db_user_firstname=$row['user_firstname'];
            $db_user_lastname=$row['user_lastname'];
            $db_user_role=$row['user_role'];
       }

    //    $password=password_verify($password, $db_user_password);
    //    $password= password_hash($password, PASSWORD_BCRYPT, array('cost' => 12)); 



       if(!empty($username) && !empty($password)){

            if($username === $db_username && password_verify($password, $db_user_password)){
                    $_SESSION['username']=$db_username;
                    $_SESSION['firstname']=$db_user_firstname;
                    $_SESSION['lastname']=$db_user_lastname;
                    $_SESSION['user_role']=$db_user_role;
                    
                    header("Location:../index.php");
            
            }else{
                $_SESSION['log']="<p class='text-danger'>Username or Password are incorect</p>";
                 header("Location:../index.php");
       }
       }else{
           $_SESSION['log']="<p class='text-danger'>Fields cannot be empty</p>";
           header("Location:../index.php");


       }

    }


?>