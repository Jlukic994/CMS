<?php  include "includes/db.php"; ?>
 <?php  include "includes/header.php"; ?>

 <?php
 
    if(isset($_POST['submit'])){

        $username=trim($_POST['username']);
        $firstname=trim($_POST['firstname']);
        $lastname=trim($_POST['lastname']);
        $email=trim($_POST['email']);
        $password=trim($_POST['password']);

        if(usernameExists($username)){
            $message="<div class='text-danger'>This username already exists</div>";
        }else{
            if( emailExists($email)){
            $message="<div class='text-danger'>This email already exists</div>";
            }else{
                if(!empty($username) && !empty($firstname) && !empty($lastname) && !empty($email) && !empty($password)){

                    if(strlen($username)<4){
                        $message="<div class='text-danger'>Username needs to be longer than 4</div>";
                    }else{

                        $username= mysqli_real_escape_string($conn, $username);
                        $firstname= mysqli_real_escape_string($conn, $firstname);
                        $lastname= mysqli_real_escape_string($conn, $lastname);
                        $email=mysqli_real_escape_string($conn, $email);
                        $password=mysqli_real_escape_string($conn, $password);

                        $password= password_hash($password, PASSWORD_BCRYPT, array('cost' => 12)); 


                        $query="INSERT INTO users SET
                                username='{$username}',
                                user_firstname='{$firstname}',
                                user_lastname='{$lastname}',
                                user_email='{$email}',
                                user_password='{$password}',
                                user_role='subscriber'
                        ";

                        $register_user_query=mysqli_query($conn, $query);
                        confirmQuery($register_user_query);
                        $message="<div class='text-success'>Your Registration has been submited</div>";
                    }
                }else{
                $message="<div class='text-danger'>Fields cannot be empty</div>";
                }
            }
        }
    }else{
        $message="";
    }
 
 
 
 ?>


    <!-- Navigation -->
    
    <?php  include "includes/navigation.php"; ?>
    
 
    <!-- Page Content -->
    <div class="container">
    
<section id="login">
    <div class="container">
        <div class="row">
            <div class="col-xs-5 col-xs-offset-3">
                <div class="form-wrap">
                <h1>Register</h1>
                    <form role="form" action="registration.php" method="post" id="login-form" autocomplete="off">
                    <h3 class="text-center"><?php echo $message; ?></h3> 
                    <div class="form-group">
                            <label for="firstname" class="sr-only">firstname</label>
                            <input autocomplete="on" type="text" name="firstname" id="firstname" class="form-control" placeholder="Enter  Firstname" value="<?php echo isset($firstname) ? $firstname : '' ?>">
                        </div>
                        <div class="form-group">
                            <label for="lastname" class="sr-only">lastname</label>
                            <input autocomplete="on" type="text" name="lastname" id="lastname" class="form-control" placeholder="Enter  Lastname" value="<?php echo isset($lastname) ? $lastname : '' ?>">
                        </div>
                        <div class="form-group">
                            <label for="username" class="sr-only">username</label>
                            <input  autocomplete="on" type="text" name="username" id="username" class="form-control" placeholder="Enter  Username" value="<?php echo isset($username) ? $username : '' ?>">
                        </div>
                         <div class="form-group">
                            <label for="email" class="sr-only">Email</label>
                            <input autocomplete="on" type="email" name="email" id="email" class="form-control" placeholder="somebody@example.com" value="<?php echo isset($email) ? $email : '' ?>">
                        </div>
                         <div class="form-group">
                            <label for="password" class="sr-only">Password</label>
                            <input type="password" name="password" id="key" class="form-control" placeholder="Password">
                        </div>
                
                        <input type="submit" name="submit" id="btn-login" class="btn btn-custom btn-lg btn-block" value="Register">
                    </form>
                 
                </div>
            </div> <!-- /.col-xs-12 -->
        </div> <!-- /.row -->
    </div> <!-- /.container -->
</section>


        <hr>



<?php include "includes/footer.php";?>
